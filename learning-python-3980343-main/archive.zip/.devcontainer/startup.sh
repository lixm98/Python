if [ -f requirements.txt ]; then
  pip install --user -r requirements.txt
fi